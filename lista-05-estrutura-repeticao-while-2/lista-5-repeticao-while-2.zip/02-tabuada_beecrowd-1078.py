tabuada = int(input())
contador = 1

while (contador < 11):
    print(f'{contador} x {tabuada} = {tabuada * contador}')
    contador += 1