tempoViagem = int(input())
velocidade = int(input())

distancia = velocidade * tempoViagem

consumo = distancia/12

print(f'{consumo:.3f}')